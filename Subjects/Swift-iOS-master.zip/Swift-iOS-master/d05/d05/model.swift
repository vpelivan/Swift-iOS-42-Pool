//
//  model.swift
//  d05
//
//  Created by Vyacheslav GLADUSH on 09.10.2018.
//  Copyright © 2018 Vyacheslav GLADUSH. All rights reserved.
//

import Foundation

struct Data {
    static var locations : [(Double, Double, String, String)] = [
        (48.8918717, 2.3216461, "Ecole 42", "Franch"),
        (37.4407933, -122.2378968, "42 Silicon Valley", "USA"),
        (50.4688257, 30.4599648, "UNIT Factory", "Ukraine")
    ]
}
