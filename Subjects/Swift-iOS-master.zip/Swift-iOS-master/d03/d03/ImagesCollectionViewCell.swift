//
//  ImagesCollectionViewCell.swift
//  d03
//
//  Created by Ivan BOHONOSIUK on 04.10.2018.
//  Copyright © 2018 Ivan BOHONOSIUK. All rights reserved.
//

import UIKit

class ImagesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var loader: UIActivityIndicatorView!
    @IBOutlet weak var imageLabel: UIImageView!
}
