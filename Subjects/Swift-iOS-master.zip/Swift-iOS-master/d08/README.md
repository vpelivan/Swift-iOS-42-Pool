# vgladush2018

[![CI Status](https://img.shields.io/travis/Dude-Rocker/vgladush2018.svg?style=flat)](https://travis-ci.org/Dude-Rocker/vgladush2018)
[![Version](https://img.shields.io/cocoapods/v/vgladush2018.svg?style=flat)](https://cocoapods.org/pods/vgladush2018)
[![License](https://img.shields.io/cocoapods/l/vgladush2018.svg?style=flat)](https://cocoapods.org/pods/vgladush2018)
[![Platform](https://img.shields.io/cocoapods/p/vgladush2018.svg?style=flat)](https://cocoapods.org/pods/vgladush2018)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

vgladush2018 is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'vgladush2018'
```

## Author

Dude-Rocker, vgladush@student.unit.ua

## License

vgladush2018 is available under the MIT license. See the LICENSE file for more info.
