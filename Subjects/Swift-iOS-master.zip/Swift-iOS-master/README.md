# Piscine Swift iOS
## The project of school 42
### Piscine is introduction to new technologies (programming language) as quickly and efficiently as possible
<table>
	<tr>
		<th rowspan="2" align="center">Days</th>
		<th colspan="2" align="center">Exercises</th>
		<th rowspan="2" align="center">Intra</th>
	</tr>
	<tr>
		<th align="center">Done</th>
		<th align="center">Total</th>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d00.pdf">Day 00</a></td>
		<td align="center">5</td>
		<td align="center">5</td>
		<td rowspan="12" align="center"><img src="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/swift_ios.png" alt="total result"></td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d01.pdf">Day 01</a></td>
		<td align="center">5</td>
		<td align="center">5</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d02.pdf">Day 02</a></td>
		<td align="center">6</td>
		<td align="center">6</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d03.pdf">Day 03</a></td>
		<td align="center">5</td>
		<td align="center">5</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d04.pdf">Day 04</a></td>
		<td align="center">2</td>
		<td align="center">6</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/rush00.pdf">Rush00</a></td>
		<td align="center">0</td>
		<td align="center">1</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d05.pdf">Day 05</a></td>
		<td align="center">4</td>
		<td align="center">7</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d06.pdf">Day 06</a></td>
		<td align="center">3</td>
		<td align="center">4</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d07.pdf">Day 07</a></td>
		<td align="center">0</td>
		<td align="center">5</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d08.pdf">Day 08</a></td>
		<td align="center">?</td>
		<td align="center">?</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/d09.pdf">Day 09</a></td>
		<td align="center">0</td>
		<td align="center">?</td>
	</tr>
	<tr>
		<td align="center"><a href="https://github.com/Dude-Rocker/resources/blob/master/piscine_swift-ios/rush01.pdf">Rush01</a></td>
		<td align="center">1</td>
		<td align="center">1</td>
	</tr>
</table>

## Final result:
![](https://github.com/Dude-Rocker/resources/blob/master/img/success.png)
