//
//  Model.swift
//  d02
//
//  Created by Sergiy SHILINGOV on 10/3/18.
//  Copyright © 2018 Sergiy SHILINGOV. All rights reserved.
//

import Foundation

struct Data {
    static var names : [(String, String, String)] = [
        ("Rick", "Gunned down", "15 October 2018 23:11:15"),
        ("John", "Killed by luke", "21 October 2018 17:16:08"),
        ("Luke", "Executed", "12 November 2018 12:00:43")
    ]
}
