//
//  ViewController.swift
//  04
//
//  Created by Viktor PELIVAN on 10/3/19.
//  Copyright © 2019 Viktor PELIVAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, APITwitterDelegate {
    func enableTweet(_ tweets: [Tweet]) {
        <#code#>
    }
    
    func enableError(_ error: NSError) {
        <#code#>
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

